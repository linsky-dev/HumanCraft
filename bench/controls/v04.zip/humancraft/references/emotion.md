---
name: skills-humancraft-references-emotion
description: 'HumanCraft supporting resource: Emotion: first impression, use, lasting
  meaning. Read only when relevant to the current task.'
---

# Emotion: first impression, use, lasting meaning

Use the three lenses together, not as rigid brain categories: immediate sensory response (visceral), task experience (behavioral), and interpretation/memory/identity (reflective). Aesthetics can influence perceived experience but cannot prove usability or excuse inaccessible behavior.

- Immediate: establish a visual language suited to context, readable hierarchy, typography, spacing, coherent colors, and calm first impression. Avoid generic decoration where it obscures information.
- During use: minimize preventable frustration, maintain fast and intelligible feedback, make success and recovery clear, preserve control. Sound and motion must be purposeful, optional where possible, and respect reduced-motion needs.
- Afterwards: leave a truthful completion receipt, meaningful accomplishment, clear next steps and trustworthy history. Support customization when it benefits users without creating unnecessary setup.

Design for the emotion a task warrants: reassurance in financial or account recovery, focus in enterprise operations, play in a game. Avoid forced celebration, guilt, anxiety, fake urgency, deceptive consent and addictive reward loops. Do not claim to know a person's emotion without evidence.

Verify visual hierarchy, language and feedback with a realistic task; ask users to describe confidence, trust and perceived effort. Capture what users can actually do as well as what they like. Treat the three lenses as a conceptual design framework, not diagnostic neuroscience.

## Advanced behavioral checks
Trust is earned by repeated reliability; calm verified recovery is better than cheerful false success. Compare expectations, actual outcomes and receipts; assign independent review. See HC-B08/B09/B12. [Contracts](behavior-contracts.md).
